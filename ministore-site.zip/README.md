# MiniStore + Metis Admin (merged)

Static site — no build step, no server. Upload the folder as-is to Vercel, GitHub Pages, Netlify or Hostinger (public_html).

- `/`            storefront (index, shop, product, cart + checkout)
- `/admin/`      admin dashboard (password protected): Products, Orders, + the Metis template pages
- `js/config.js` **your settings** (password hash, currency, WhatsApp number, order webhook)
- `data/products.json`  the published product catalogue

## Admin login
Open `/admin/login.html`. Default password: **admin123** — change it before going live:

    node -e "console.log(require('crypto').createHash('sha256').update('YOUR-NEW-PASSWORD').digest('hex'))"

Paste the result into `adminPasswordSha256` in `js/config.js`. (Login needs HTTPS or localhost.)

## Changing products so the storefront shows them
1. Admin → Products → Add / Edit / Delete. The storefront in the same browser updates instantly.
2. To make changes live for ALL visitors: click **Publish** → it downloads `products.json` →
   replace `data/products.json` in your site and redeploy (git push on Vercel/GitHub, or upload on Hostinger).
   Tip: put product photos in `images/` and use paths like `images/my-phone.jpg` (uploaded images are stored inline and make the file big).

## Orders
Checkout saves the order in the browser and, if configured in `js/config.js`, also opens WhatsApp with the order
(`whatsappNumber`) and/or POSTs it to `orderWebhook` (e.g. a free Formspree URL -> emailed to you).
The Admin → Orders page only lists orders placed in the same browser.

## Important limits (static hosting)
- The password gate is client-side: it keeps casual visitors out but is not real security.
- There is no shared database, so live multi-device editing and stock sync need a backend (Supabase/Firebase/Vercel KV + API).
