(function () {
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var page = document.body.getAttribute('data-page') || 'home';
  var P = new URLSearchParams(location.search);
  var live = function (l) { return l.filter(function (p) { return p.active !== false; }); };

  function swipers() {
    if (!window.Swiper) return;
    [['.product-swiper', '#mobile-products'], ['.product-watch-swiper', '#smart-watches'], ['.product-more-swiper', '#more-products']].forEach(function (a) {
      if ($(a[0])) new Swiper(a[0], { slidesPerView: 2, spaceBetween: 20, pagination: { el: a[1] + ' .swiper-pagination', clickable: true }, breakpoints: { 0: { slidesPerView: 2, spaceBetween: 20 }, 980: { slidesPerView: 4, spaceBetween: 20 } } });
    });
  }
  function catList(list) {
    var el = $('.cat-list'); if (!el) return;
    var cats = Array.from(new Set(list.map(function (p) { return p.category; }).filter(Boolean)));
    el.innerHTML = cats.map(function (c) { return '<li class="cat-list-item"><a href="shop.html?cat=' + encodeURIComponent(c) + '">' + MS.esc(c) + '</a></li>'; }).join('');
  }
  function home(list) {
    function fill(sel, test) {
      var sec = $(sel); if (!sec) return;
      var items = list.filter(test);
      if (!items.length) { sec.style.display = 'none'; return; }
      $('.swiper-wrapper', sec).innerHTML = items.map(function (p) { return '<div class="swiper-slide">' + MS.cardHTML(p) + '</div>'; }).join('');
    }
    fill('#mobile-products', function (p) { return p.category === 'Mobile Phones'; });
    fill('#smart-watches', function (p) { return p.category === 'Smart Watches'; });
    fill('#more-products', function (p) { return p.category !== 'Mobile Phones' && p.category !== 'Smart Watches'; });
    swipers();
  }
  function shop(list) {
    var root = $('#shop-root'), cat = P.get('cat') || '', q = (P.get('q') || P.get('s') || '').toLowerCase(), sort = P.get('sort') || '';
    var cats = Array.from(new Set(list.map(function (p) { return p.category; }).filter(Boolean)));
    function draw() {
      var items = list.filter(function (p) { return (!cat || p.category === cat) && (!q || (p.name + ' ' + p.category).toLowerCase().indexOf(q) > -1); });
      if (sort === 'low') items.sort(function (a, b) { return a.price - b.price; });
      if (sort === 'high') items.sort(function (a, b) { return b.price - a.price; });
      $('#shop-grid').innerHTML = items.length ? items.map(function (p) { return '<div class="col-6 col-md-4 col-lg-3 mb-4">' + MS.cardHTML(p) + '</div>'; }).join('') : '<p class="text-muted">No products found.</p>';
      $('#shop-count').textContent = items.length + ' product' + (items.length === 1 ? '' : 's');
    }
    root.innerHTML = '<div class="d-flex flex-wrap gap-2 align-items-center justify-content-between mb-4">' +
      '<div class="d-flex flex-wrap gap-2" id="chips"></div>' +
      '<div class="d-flex gap-2"><input id="shop-q" class="form-control" placeholder="Search…" value="' + MS.esc(P.get('q') || '') + '">' +
      '<select id="shop-sort" class="form-select"><option value="">Sort</option><option value="low">Price: low to high</option><option value="high">Price: high to low</option></select></div></div>' +
      '<p class="text-muted small" id="shop-count"></p><div class="row" id="shop-grid"></div>';
    var chips = $('#chips');
    chips.innerHTML = ['All'].concat(cats).map(function (c) { var on = (c === 'All' && !cat) || c === cat; return '<button class="btn btn-sm ' + (on ? 'btn-dark' : 'btn-outline-dark') + '" data-c="' + MS.esc(c === 'All' ? '' : c) + '">' + MS.esc(c) + '</button>'; }).join('');
    chips.onclick = function (e) { var b = e.target.closest('[data-c]'); if (!b) return; cat = b.getAttribute('data-c'); chips.querySelectorAll('button').forEach(function (x) { x.className = 'btn btn-sm ' + (x === b ? 'btn-dark' : 'btn-outline-dark'); }); draw(); };
    $('#shop-q').oninput = function (e) { q = e.target.value.toLowerCase(); draw(); };
    $('#shop-sort').value = sort; $('#shop-sort').onchange = function (e) { sort = e.target.value; draw(); };
    draw();
  }
  function product(list) {
    var p = list.find(function (x) { return x.id === P.get('id'); }), root = $('#product-root');
    if (!p) { root.innerHTML = '<p>Product not found. <a href="shop.html">Back to shop</a></p>'; return; }
    document.title = p.name + ' – MiniStore';
    var out = Number(p.stock) <= 0;
    root.innerHTML = '<div class="row g-5"><div class="col-md-6"><img class="img-fluid w-100" src="' + MS.esc(MS.img(p)) + '" alt="' + MS.esc(p.name) + '"></div>' +
      '<div class="col-md-6"><p class="text-muted text-uppercase small mb-1">' + MS.esc(p.category) + '</p><h1 class="display-6 text-uppercase">' + MS.esc(p.name) + '</h1>' +
      '<p class="fs-3 text-primary">' + MS.money(p.price) + '</p><p>' + MS.esc(p.description) + '</p>' +
      '<p class="small ' + (out ? 'text-danger' : 'text-success') + '">' + (out ? 'Out of stock' : (p.stock <= 5 ? 'Only ' + p.stock + ' left' : 'In stock')) + '</p>' +
      '<div class="d-flex gap-2 mb-3"><input id="pq" type="number" min="1" max="' + (+p.stock || 1) + '" value="1" class="form-control qty-inline"><button id="padd" class="btn btn-dark"' + (out ? ' disabled' : '') + '>Add to cart</button></div>' +
      '<a href="shop.html" class="small">← Continue shopping</a></div></div>';
    $('#padd').onclick = function () { MS.addToCart(p.id, Math.max(1, Math.min(+$('#pq').value || 1, +p.stock))); MS.toast('Added to cart'); };
  }
  function cart(list) {
    var root = $('#cart-root');
    function lines() { return MS.cart().map(function (i) { var p = list.find(function (x) { return x.id === i.id; }); return p ? { p: p, qty: Math.min(i.qty, Math.max(+p.stock, 0)) } : null; }).filter(function (l) { return l && l.qty > 0; }); }
    function draw() {
      var L = lines(), total = L.reduce(function (a, l) { return a + l.p.price * l.qty; }, 0);
      if (!L.length) { root.innerHTML = '<div class="text-center py-5"><h2>Your cart is empty</h2><a class="btn btn-dark mt-3" href="shop.html">Browse products</a></div>'; return; }
      root.innerHTML = '<div class="row g-5"><div class="col-lg-7"><div class="table-responsive"><table class="table align-middle"><tbody>' +
        L.map(function (l) { return '<tr><td><img class="cart-thumb" src="' + MS.esc(MS.img(l.p)) + '"></td><td>' + MS.esc(l.p.name) + '<br><small class="text-muted">' + MS.money(l.p.price) + '</small></td>' +
          '<td><input type="number" min="0" max="' + l.p.stock + '" value="' + l.qty + '" data-q="' + MS.esc(l.p.id) + '" class="form-control qty-inline"></td><td class="text-end">' + MS.money(l.p.price * l.qty) + '</td>' +
          '<td><button class="btn btn-sm btn-outline-danger" data-rm="' + MS.esc(l.p.id) + '">&times;</button></td></tr>'; }).join('') + '</tbody></table></div></div>' +
        '<div class="col-lg-5"><h4>Checkout</h4><form id="co" class="row g-2"><div class="col-12"><input required name="name" class="form-control" placeholder="Full name"></div>' +
        '<div class="col-6"><input required name="phone" class="form-control" placeholder="Phone"></div><div class="col-6"><input name="email" type="email" class="form-control" placeholder="Email (optional)"></div>' +
        '<div class="col-12"><textarea required name="address" rows="3" class="form-control" placeholder="Delivery address"></textarea></div><div class="col-12"><input name="notes" class="form-control" placeholder="Notes (optional)"></div>' +
        '<div class="col-12 d-flex justify-content-between fs-5 mt-2"><strong>Total</strong><strong>' + MS.money(total) + '</strong></div>' +
        '<div class="col-12"><button class="btn btn-dark w-100">Place order</button><p class="small text-muted mt-2 mb-0">Payment: cash on delivery / arranged by the store after your order.</p></div></form></div></div>';
      root.querySelectorAll('[data-q]').forEach(function (i) { i.onchange = function () { MS.setQty(i.getAttribute('data-q'), Math.max(0, Math.floor(+i.value || 0))); draw(); }; });
      root.querySelectorAll('[data-rm]').forEach(function (b) { b.onclick = function () { MS.setQty(b.getAttribute('data-rm'), 0); draw(); }; });
      $('#co').onsubmit = function (e) {
        e.preventDefault(); var f = new FormData(e.target);
        var order = { id: 'MS-' + Date.now().toString(36).toUpperCase(), date: new Date().toISOString(), status: 'Pending', total: total,
          customer: { name: f.get('name'), phone: f.get('phone'), email: f.get('email'), address: f.get('address'), notes: f.get('notes') },
          items: L.map(function (l) { return { id: l.p.id, name: l.p.name, price: l.p.price, qty: l.qty }; }) };
        var o = MS.orders(); o.unshift(order); MS.saveOrders(o);
        var C = MS.config;
        if (C.whatsappNumber) {
          var t = 'New order ' + order.id + '\n' + order.items.map(function (i) { return i.qty + ' x ' + i.name; }).join('\n') + '\nTotal: ' + MS.money(total) + '\n' + order.customer.name + ', ' + order.customer.phone + '\n' + order.customer.address;
          window.open('https://wa.me/' + C.whatsappNumber + '?text=' + encodeURIComponent(t), '_blank');
        }
        if (C.orderWebhook) fetch(C.orderWebhook, { method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify(order) }).catch(function () {});
        MS.clearCart();
        root.innerHTML = '<div class="text-center py-5"><h2>Thank you, ' + MS.esc(order.customer.name) + '!</h2><p>Your order <strong>' + order.id + '</strong> has been placed. We will contact you on ' + MS.esc(order.customer.phone) + '.</p><a class="btn btn-dark" href="shop.html">Continue shopping</a></div>';
      };
    }
    draw();
  }
  MS.getProducts().then(function (all) {
    var list = live(all); catList(list);
    ({ home: home, shop: shop, product: product, cart: cart }[page] || function () {})(list);
  });
})();
