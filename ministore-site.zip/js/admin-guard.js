/* Password lock for the admin. NOTE: client-side gate — see README for hardening. */
(function () {
  var C = window.MS_CONFIG || {};
  function valid() {
    try {
      if (sessionStorage.getItem('ms_admin') === '1') return true;
      var u = +localStorage.getItem('ms_admin_until'); return u && u > Date.now();
    } catch (e) { return false; }
  }
  function sha(s) {
    if (!(window.crypto && crypto.subtle)) return Promise.reject(new Error('Login needs HTTPS (or localhost).'));
    return crypto.subtle.digest('SHA-256', new TextEncoder().encode(s)).then(function (b) {
      return Array.from(new Uint8Array(b)).map(function (x) { return x.toString(16).padStart(2, '0'); }).join('');
    });
  }
  window.MSAuth = {
    login: function (pw, remember) {
      var lock = +localStorage.getItem('ms_lock_until') || 0;
      if (lock > Date.now()) return Promise.resolve({ ok: false, msg: 'Too many attempts. Try again in ' + Math.ceil((lock - Date.now()) / 1000) + 's.' });
      return sha(pw).then(function (h) {
        if (h === C.adminPasswordSha256) {
          localStorage.removeItem('ms_fails');
          sessionStorage.setItem('ms_admin', '1');
          if (remember) localStorage.setItem('ms_admin_until', Date.now() + 30 * 864e5);
          return { ok: true };
        }
        var f = (+localStorage.getItem('ms_fails') || 0) + 1; localStorage.setItem('ms_fails', f);
        if (f >= 5) { localStorage.setItem('ms_lock_until', Date.now() + 30000); localStorage.setItem('ms_fails', 0); }
        return { ok: false, msg: 'Incorrect password.' };
      }).catch(function (e) { return { ok: false, msg: e.message }; });
    },
    logout: function () { try { sessionStorage.removeItem('ms_admin'); localStorage.removeItem('ms_admin_until'); } catch (e) {} }
  };
  var onLogin = /login\.html$/.test(location.pathname);
  if (!onLogin && !valid()) {
    document.documentElement.style.display = 'none';
    location.replace('login.html?next=' + encodeURIComponent(location.pathname.split('/').pop() + location.search));
  }
  document.addEventListener('click', function (e) {
    var a = e.target.closest && e.target.closest('a[href$="login.html"]');
    if (a && !onLogin) MSAuth.logout();
  });
})();
