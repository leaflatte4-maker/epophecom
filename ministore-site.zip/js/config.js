/* ===== Store settings — edit this file ===== */
window.MS_CONFIG = {
  storeName: "MiniStore",
  currency: "$",
  lowStockAt: 5,
  // SHA-256 of the admin password. Default password is: admin123  (CHANGE IT — see README)
  adminPasswordSha256: "240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9",
  // Optional: customers' orders are also sent here when set
  whatsappNumber: "",   // e.g. "919876543210" (country code, no + or spaces). Opens WhatsApp with the order.
  orderWebhook: ""      // e.g. a Formspree URL "https://formspree.io/f/xxxx" — receives each order as JSON by email
};
