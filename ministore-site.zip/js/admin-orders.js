(function () {
  var $ = function (s) { return document.querySelector(s); }, orders = MS.orders(), ST = ['Pending', 'Confirmed', 'Shipped', 'Delivered', 'Cancelled'];
  function draw() {
    var rev = orders.filter(function (o) { return o.status !== 'Cancelled'; }).reduce(function (a, o) { return a + o.total; }, 0);
    $('#ostats').innerHTML = [['Orders', orders.length], ['Pending', orders.filter(function (o) { return o.status === 'Pending'; }).length], ['Revenue', MS.money(rev)]].map(function (s) { return '<div class="col-6 col-lg-4"><div class="card"><div class="card-body"><div class="text-muted small">' + s[0] + '</div><div class="h3 mb-0">' + s[1] + '</div></div></div></div>'; }).join('');
    $('#otbody').innerHTML = orders.map(function (o) {
      return '<tr><td><b>' + MS.esc(o.id) + '</b></td><td class="text-nowrap">' + new Date(o.date).toLocaleString() + '</td><td>' + MS.esc(o.customer.name) + '<br><small class="text-muted">' + MS.esc(o.customer.phone) + '<br>' + MS.esc(o.customer.address) + '</small></td>' +
        '<td>' + o.items.map(function (i) { return i.qty + ' × ' + MS.esc(i.name); }).join('<br>') + '</td><td>' + MS.money(o.total) + '</td>' +
        '<td><select class="form-select form-select-sm" data-s="' + o.id + '">' + ST.map(function (s) { return '<option' + (s === o.status ? ' selected' : '') + '>' + s + '</option>'; }).join('') + '</select></td>' +
        '<td><button class="btn btn-sm btn-outline-danger" data-d="' + o.id + '"><i class="bi bi-trash"></i></button></td></tr>';
    }).join('') || '<tr><td colspan="7" class="text-center text-muted py-4">No orders yet</td></tr>';
  }
  $('#otbody').onchange = function (e) { var s = e.target.getAttribute('data-s'); if (!s) return; orders.find(function (o) { return o.id === s; }).status = e.target.value; MS.saveOrders(orders); draw(); };
  $('#otbody').onclick = function (e) { var d = e.target.closest('[data-d]'); if (d && confirm('Delete order?')) { orders = orders.filter(function (o) { return o.id !== d.getAttribute('data-d'); }); MS.saveOrders(orders); draw(); } };
  $('#o-export').onclick = function () {
    var q = function (v) { return '"' + String(v).replace(/"/g, '""') + '"'; };
    var csv = ['id,date,name,phone,email,address,items,total,status'].concat(orders.map(function (o) { return [o.id, o.date, o.customer.name, o.customer.phone, o.customer.email, o.customer.address, o.items.map(function (i) { return i.qty + 'x ' + i.name; }).join('; '), o.total, o.status].map(q).join(','); })).join('\n');
    var a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' })); a.download = 'orders.csv'; a.click();
  };
  draw();
})();
