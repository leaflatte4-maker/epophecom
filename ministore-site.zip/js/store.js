/* Shared data layer for the storefront AND the admin. Products: admin draft (localStorage) -> data/products.json */
(function () {
  var C = window.MS_CONFIG || {};
  var ROOT = new URL('../', document.currentScript.src).href;
  var ls = {
    get: function (k, d) { try { var v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
    set: function (k, v) { try { localStorage.setItem(k, JSON.stringify(v)); return true; } catch (e) { return false; } },
    del: function (k) { try { localStorage.removeItem(k); } catch (e) {} }
  };
  var MS = window.MS = {
    root: ROOT, config: C,
    esc: function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); },
    money: function (n) { return (C.currency || '$') + Number(n || 0).toLocaleString(undefined, { maximumFractionDigits: 2 }); },
    img: function (p) { var i = p.image || ''; return /^(data:|https?:|\/\/)/.test(i) ? i : ROOT + (i || 'images/main-logo.png'); },
    hasDraft: function () { try { return localStorage.getItem('ms_products') !== null; } catch (e) { return false; } },
    getProducts: function () {
      var d = ls.get('ms_products', null);
      if (d) return Promise.resolve(d);
      return fetch(ROOT + 'data/products.json', { cache: 'no-cache' }).then(function (r) { return r.json(); }).then(function (j) { return j.products || []; }).catch(function () { return []; });
    },
    saveProducts: function (list) { return ls.set('ms_products', list); },
    resetProducts: function () { ls.del('ms_products'); },
    cart: function () { return ls.get('ms_cart', []); },
    cartCount: function () { return MS.cart().reduce(function (a, i) { return a + i.qty; }, 0); },
    addToCart: function (id, qty) {
      var c = MS.cart(), it = c.find(function (i) { return i.id === id; });
      if (it) it.qty += qty || 1; else c.push({ id: id, qty: qty || 1 });
      ls.set('ms_cart', c); MS.updateBadge();
    },
    setQty: function (id, q) { var c = MS.cart().map(function (i) { if (i.id === id) i.qty = q; return i; }).filter(function (i) { return i.qty > 0; }); ls.set('ms_cart', c); MS.updateBadge(); },
    clearCart: function () { ls.del('ms_cart'); MS.updateBadge(); },
    updateBadge: function () { document.querySelectorAll('[data-cart-count]').forEach(function (e) { var n = MS.cartCount(); e.textContent = n; e.style.display = n ? '' : 'none'; }); },
    orders: function () { return ls.get('ms_orders', []); },
    saveOrders: function (o) { return ls.set('ms_orders', o); },
    toast: function (msg) {
      var t = document.createElement('div'); t.textContent = msg;
      t.style.cssText = 'position:fixed;left:50%;bottom:24px;transform:translateX(-50%);background:#111;color:#fff;padding:10px 18px;border-radius:6px;z-index:9999;font-size:14px';
      document.body.appendChild(t); setTimeout(function () { t.remove(); }, 1800);
    },
    cardHTML: function (p) {
      var out = Number(p.stock) <= 0;
      return '<div class="product-card position-relative"><div class="image-holder"><a href="product.html?id=' + MS.esc(p.id) + '"><img src="' + MS.esc(MS.img(p)) + '" alt="' + MS.esc(p.name) + '" class="img-fluid"></a>' +
        (out ? '<span class="badge bg-dark position-absolute top-0 start-0 m-2">Sold out</span>' : '') + '</div>' +
        '<div class="cart-concern position-absolute"><div class="cart-button d-flex"><a href="#" data-add="' + MS.esc(p.id) + '" class="btn btn-medium btn-black' + (out ? ' disabled' : '') + '">' + (out ? 'Sold out' : 'Add to Cart') + '<svg class="cart-outline"><use xlink:href="#cart-outline"></use></svg></a></div></div>' +
        '<div class="card-detail d-flex justify-content-between align-items-baseline pt-3"><h3 class="card-title text-uppercase"><a href="product.html?id=' + MS.esc(p.id) + '">' + MS.esc(p.name) + '</a></h3><span class="item-price text-primary">' + MS.money(p.price) + '</span></div></div>';
    }
  };
  document.addEventListener('click', function (e) {
    var a = e.target.closest && e.target.closest('[data-add]');
    if (!a) return; e.preventDefault();
    if (a.classList.contains('disabled')) return;
    MS.addToCart(a.getAttribute('data-add'), 1); MS.toast('Added to cart');
  });
  document.addEventListener('DOMContentLoaded', MS.updateBadge);
})();
