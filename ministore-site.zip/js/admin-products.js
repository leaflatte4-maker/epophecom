(function () {
  var $ = function (s) { return document.querySelector(s); }, list = [], C = MS.config;
  function save() { if (!MS.saveProducts(list)) alert('Could not save (browser storage full?). Use smaller images or image paths.'); draw(); }
  function stats() {
    var low = list.filter(function (p) { return p.stock > 0 && p.stock <= (C.lowStockAt || 5); }).length, out = list.filter(function (p) { return p.stock <= 0; }).length;
    var cats = new Set(list.map(function (p) { return p.category; })).size;
    $('#stats').innerHTML = [['Products', list.length], ['Categories', cats], ['Low stock', low], ['Out of stock', out]].map(function (s) { return '<div class="col-6 col-lg-3"><div class="card"><div class="card-body"><div class="text-muted small">' + s[0] + '</div><div class="h3 mb-0">' + s[1] + '</div></div></div></div>'; }).join('');
    var cs = Array.from(new Set(list.map(function (p) { return p.category; }))), cur = $('#f-cat').value;
    $('#f-cat').innerHTML = '<option value="">All categories</option>' + cs.map(function (c) { return '<option' + (c === cur ? ' selected' : '') + '>' + MS.esc(c) + '</option>'; }).join('');
    $('#cats').innerHTML = cs.map(function (c) { return '<option value="' + MS.esc(c) + '">'; }).join('');
  }
  function draw() {
    stats();
    var q = $('#f-q').value.toLowerCase(), c = $('#f-cat').value;
    var rows = list.filter(function (p) { return (!c || p.category === c) && (!q || (p.name + p.category).toLowerCase().indexOf(q) > -1); });
    $('#ptbody').innerHTML = rows.map(function (p) {
      var st = p.active === false ? '<span class="badge bg-secondary">Hidden</span>' : p.stock <= 0 ? '<span class="badge bg-danger">Sold out</span>' : p.stock <= (C.lowStockAt || 5) ? '<span class="badge bg-warning text-dark">Low</span>' : '<span class="badge bg-success">Live</span>';
      return '<tr><td><img src="' + MS.esc(MS.img(p)) + '" style="width:48px;height:48px;object-fit:cover;border-radius:6px"></td><td>' + MS.esc(p.name) + '</td><td>' + MS.esc(p.category) + '</td><td>' + MS.money(p.price) + '</td><td>' + p.stock + '</td><td>' + st + '</td>' +
        '<td class="text-end text-nowrap"><button class="btn btn-sm btn-outline-primary" data-e="' + MS.esc(p.id) + '"><i class="bi bi-pencil"></i></button> <button class="btn btn-sm btn-outline-danger" data-d="' + MS.esc(p.id) + '"><i class="bi bi-trash"></i></button></td></tr>';
    }).join('') || '<tr><td colspan="7" class="text-center text-muted py-4">No products</td></tr>';
  }
  function openForm(p) {
    var f = $('#pform'); p = p || { id: '', name: '', category: '', price: '', stock: 10, image: '', description: '', active: true };
    f.id.value = p.id; f.name.value = p.name; f.category.value = p.category; f.price.value = p.price; f.stock.value = p.stock; f.image.value = p.image; f.description.value = p.description || ''; f.active.value = p.active === false ? '0' : '1';
    $('#form-title').textContent = p.id ? 'Edit product' : 'Add product'; $('#form-card').style.display = ''; prev(); $('#form-card').scrollIntoView({ behavior: 'smooth' });
  }
  function prev() { var v = $('#pform').image.value, i = $('#img-prev'); if (v) { i.src = MS.img({ image: v }); i.style.display = ''; } else i.style.display = 'none'; }
  function resize(file, cb) {
    var r = new FileReader(); r.onload = function () { var im = new Image(); im.onload = function () {
      var m = 700, s = Math.min(1, m / Math.max(im.width, im.height)), c = document.createElement('canvas'); c.width = im.width * s; c.height = im.height * s;
      c.getContext('2d').drawImage(im, 0, 0, c.width, c.height); cb(c.toDataURL('image/jpeg', 0.8)); }; im.src = r.result; }; r.readAsDataURL(file);
  }
  $('#btn-add').onclick = function () { openForm(); };
  $('#btn-cancel').onclick = function () { $('#form-card').style.display = 'none'; };
  $('#pform').image.oninput = prev;
  $('#img-file').onchange = function (e) { if (e.target.files[0]) resize(e.target.files[0], function (d) { $('#pform').image.value = d; prev(); }); };
  $('#pform').onsubmit = function (e) {
    e.preventDefault(); var f = e.target;
    var p = { id: f.id.value || 'p' + Date.now().toString(36), name: f.name.value.trim(), category: f.category.value.trim(), price: +f.price.value, stock: Math.max(0, parseInt(f.stock.value, 10) || 0), image: f.image.value.trim(), description: f.description.value.trim(), active: f.active.value === '1' };
    var i = list.findIndex(function (x) { return x.id === p.id; }); if (i > -1) list[i] = p; else list.unshift(p);
    save(); $('#form-card').style.display = 'none'; MS.toast('Saved — live in the store');
  };
  $('#ptbody').onclick = function (e) {
    var ed = e.target.closest('[data-e]'), de = e.target.closest('[data-d]');
    if (ed) openForm(list.find(function (p) { return p.id === ed.getAttribute('data-e'); }));
    if (de && confirm('Delete this product?')) { list = list.filter(function (p) { return p.id !== de.getAttribute('data-d'); }); save(); }
  };
  $('#f-q').oninput = draw; $('#f-cat').onchange = draw;
  $('#btn-publish').onclick = function () {
    var a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([JSON.stringify({ products: list }, null, 1)], { type: 'application/json' })); a.download = 'products.json'; a.click();
  };
  $('#btn-import').onclick = function () { $('#import-file').click(); };
  $('#import-file').onchange = function (e) {
    var r = new FileReader(); r.onload = function () { try { var j = JSON.parse(r.result); list = j.products || j; if (!Array.isArray(list)) throw 0; save(); MS.toast('Imported'); } catch (x) { alert('Invalid products.json'); } }; if (e.target.files[0]) r.readAsText(e.target.files[0]);
  };
  $('#btn-reset').onclick = function () { if (confirm('Discard your edits in this browser and reload the published data/products.json?')) { MS.resetProducts(); MS.getProducts().then(function (l) { list = l; draw(); }); } };
  MS.getProducts().then(function (l) { list = l; draw(); });
})();
